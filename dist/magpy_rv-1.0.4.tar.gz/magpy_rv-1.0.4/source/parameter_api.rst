.. _parameter_api:

Parameter Functions
===================

.. automodule:: src.magpy_rv.parameters
    :members:
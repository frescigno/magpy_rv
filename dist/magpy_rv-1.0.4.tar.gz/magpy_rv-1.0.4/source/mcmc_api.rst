.. _mcmc_api:

MCMC Functions
================

.. automodule:: src.magpy_rv.mcmc
    :members:
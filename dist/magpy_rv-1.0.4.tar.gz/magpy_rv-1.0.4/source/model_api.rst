.. _model_api:

Model Functions
===============

.. automodule:: src.magpy_rv.models
    :members:
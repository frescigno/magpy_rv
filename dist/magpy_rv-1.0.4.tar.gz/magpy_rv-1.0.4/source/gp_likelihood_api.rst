.. _gp_likelihood_api:

GP Likelihood Functions
=======================

.. automodule:: src.magpy_rv.gp_likelihood
    :members:
.. magpy_rv documentation master file, created by
   sphinx-quickstart on Tue Aug 22 16:04:06 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to magpy_rv's documentation!
====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   install
   gettingstarted
   api


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

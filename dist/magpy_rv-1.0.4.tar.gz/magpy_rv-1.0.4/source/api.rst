.. _api:

API
===

.. toctree::
   :maxdepth: 2

   kernel_api
   parameter_api
   model_api
   gp_likelihood_api
   mcmc_api
   plotting_api
   saving_api
   mcmc_aux_api
   auxiliary_api

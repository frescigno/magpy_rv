.. _mcmc_aux_api:

MCMC Auxiliary Functions
========================

.. automodule:: src.magpy_rv.mcmc_aux
    :members:
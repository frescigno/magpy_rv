.. _plotting_api:

Plotting Functions
================

.. automodule:: src.magpy_rv.plotting
    :members: